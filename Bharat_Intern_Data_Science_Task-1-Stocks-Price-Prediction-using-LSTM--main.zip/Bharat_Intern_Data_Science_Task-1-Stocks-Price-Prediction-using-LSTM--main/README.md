# Bharat_Intern_Data_Science_Task-1-Stocks-Prediction-using-LSTM-
Take stock price of any company you want and predicts its price by using LSTM.
